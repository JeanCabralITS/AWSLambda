**To delete a route table**

This example deletes the specified route table. If the command succeeds, no output is returned.

Command::

  aws ec2 delete-route-table --route-table-id rtb-22574640
