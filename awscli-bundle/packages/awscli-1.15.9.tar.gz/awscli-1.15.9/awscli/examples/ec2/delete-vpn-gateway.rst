**To delete a virtual private gateway**

This example deletes the specified virtual private gateway. If the command succeeds, no output is returned.

Command::

  aws ec2 delete-vpn-gateway --vpn-gateway-id vgw-9a4cacf3
